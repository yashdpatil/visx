import configparser
import logging
from datetime import datetime
import csv
import os
import cx_Oracle
import psycopg2
from psycopg2 import pool
import time

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManager:

    ########################################
    ## Intialize Function That  Configure ##
    ## Database                           ##
    ##                                    ##
    ##                                    ##
    ########################################
    
    def __init__(self, config_file=r'D:\codings\Data_backups\config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        # Initialize Oracle connection
        self.oracle_user = self.config['DatabaseConfig']['oracle_user']
        self.oracle_password = self.config['DatabaseConfig']['oracle_password']
        self.oracle_dsn = self.config['DatabaseConfig']['oracle_dsn']

        # Initialize PostgreSQL connection pool
        self.postgres_user = self.config['DatabaseConfig']['postgres_user']
        self.postgres_password = self.config['DatabaseConfig']['postgres_password']
        self.postgres_host = self.config['DatabaseConfig']['postgres_host']
        self.postgres_port = self.config['DatabaseConfig']['postgres_port']
        self.postgres_db = self.config['DatabaseConfig']['postgres_db']

        self.pg_pool = pool.SimpleConnectionPool(
            1, 20, user=self.postgres_user, password=self.postgres_password,
            host=self.postgres_host, port=self.postgres_port, database=self.postgres_db
        )

    def log_time_taken(self, start_time, end_time, task_description):
        time_taken = end_time - start_time
        logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")


    ########################################
    ## Connection Establishement in Oracle##
    ## Database And Fetch Data From       ##
    ##    ORacle                          ##
    ##                                    ##
    ########################################

    def connect_to_oracle(self):
        try:
            self.oracle_connection = cx_Oracle.connect(
                user=self.oracle_user, password=self.oracle_password, dsn=self.oracle_dsn
            )
            logger.info("Connected to Oracle Database.")
            self.oracle_cursor = self.oracle_connection.cursor()
        except cx_Oracle.DatabaseError as e:
            error, = e.args
            logger.error("Oracle Database error occurred:")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.message}")

    def fetch_data_from_oracle(self):
        curr  = time.time()
        oracle_query = """
            SELECT CLM_MTCH_ACCNT, CLM_ORG_IND, CLM_CLNT_TTL, CLM_CLNT_NM, CLM_ACTV_FRM, CLM_ACTV_TO, CLM_ALLCTD_AMT,
                   CLM_PSEUDO_BNK_IND, CLM_ACCT_STTS, CLM_IBSL_CRDT_XTND, CLM_RSTRCT_LST_ID, CLM_ACCNT_CTGRY_ID,
                   CLM_CLNT_CTGRY_ID, CLM_CIF_NMBR, CLM_BLK_TRD_AMT, CLM_GRSS_EXP_LMT, CLM_B2K_CD, CLM_TDS_RT,
                   CLM_MF_ALLCTD_AMT, CLM_GRSS_LMT_UTLZD, CLM_WAP_REQ, CLM_INST_FLG, CLM_WAP_PRECISION, CLM_SLCTD_FLG,
                   CLM_CLNT_LVL, CLM_MF_MAX_OPT, CLM_MF_MAX_VAL, CLM_BTST_ALLWD_FLG, CLM_BP_ID, CLM_ALIAS_NAME,
                   CLM_TRD_FLG, CLM_PRM_BP_ID, CLM_LST_UPD_BY, CLM_LST_UPD_DT, CLM_CLNT_CD, CLM_PLG_ALLWD_FLG,
                   CLM_NCD_CLNT_LVL, CLM_BRKR_PLAN_CD, CLM_CP_CD, CLM_CDX_CLNT_LVL, CLM_PNNY_FLG, CLM_FNO_FEATURES,
                   CLM_BRKR_CMPT_FLG, CLM_OPT_SCHM_CD, CLM_SPAN_ALLWD, CLM_PREPAID_ALLWD, CLM_BSESPAN_ALLWD,
                   CLM_LPC_PRCNTG, CLM_PRPD_CUST_TYP, CLM_NCD_FLG, CLM_IGAIN_FP_FLG, CLM_IGAIN_FP_SCHM_CD,
                   CLM_IGAIN_OP_FLG, CLM_IGAIN_OP_SCHM_CD, CLM_PLG_LSTPRCS_TM, CLM_MF_TPA_ALLCTD_AMT,
                   CLM_BULLET_SCHM_FLG, CLM_BULLET_SCHM_TRIAL_FLG, CLM_ISEC_MRGN_AMT_NSE, CLM_ISEC_MRGN_AMT_BSE,
                   CLM_SQRFMD_STTS, CLM_SQRFMD_UPD_DT, CLM_ESOP_ALLWD, CLM_WALLET_AMT, CLM_IPO_ALLCTD_AMT,
                   CLM_EQ_BNK_ALLCTD_AMT, CLM_MF_BNK_ALLCTD_AMT, CLM_QRTLY_STLMNT_DT, CLM_OP20_FLG, CLM_OP20_SCHM_CD,
                   CLM_PLG_MODE, CLM_MF_MODE_DT, CLM_MF_DMAT_ACC, CLM_CDX_SPAN_ALLWD, CLM_ISEC_T5_AMT,
                   CLM_PREF_XCHNG_CD, CLM_EXCPTN_MTF_CLIENT_LVL_LMT, CLM_EXCPTN_MTF_CLNT_CHK, CLM_MF_ALLCTD_AMT_DEP,
                   CLM_RPTS_CNSNT_FLG, CLM_CNT_PENNY_ORDR_FLG, CLM_EXCPTN_CNT_IND, CLM_LOW_VOL_TRD_FLG, CLM_FLT_BRKG_FLG,
                   CLM_UPSTREAM_AMT, CLM_BRZE_FLG, CLM_CUST_LMT, CLM_FD_ALLCTD_AMT
            FROM CLM_CLNT_MSTR
        """
        self.oracle_cursor.execute(oracle_query)
        self.rows = self.oracle_cursor.fetchall()
        end = time.time()
        print("time : ",end-curr)
        logger.info(f"Fetched {len(self.rows)} rows from Oracle.")



    ########################################
    ## Connection Establishement in       ##
    ## PostgresSql Database And           ##
    ## Insert Data From    PostgresSql    ##
    ##                                    ##
    ########################################

    def connect_to_postgres(self):
        try:
            self.postgres_connection = self.pg_pool.getconn()
            logger.info("Connected to PostgreSQL Database.")
            self.postgres_cursor = self.postgres_connection.cursor()
        except psycopg2.DatabaseError as e:
            logger.error("PostgreSQL Database error occurred:")
            logger.error(f"Error message: {e}")

    def insert_data_to_postgres(self):
        if self.rows:
            insert_start_time = datetime.now()
            csv_file_path = 'rows.csv'
            with open(csv_file_path, mode='w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file)
                csv_writer.writerows(self.rows)

            # Use COPY command to bulk insert data
          
            with open(csv_file_path, mode='r') as csv_file:
                self.postgres_cursor.copy_expert(
                    """
                    COPY CLM_CLNT_MSTR (
                        CLM_MTCH_ACCNT, CLM_ORG_IND, CLM_CLNT_TTL, CLM_CLNT_NM, CLM_ACTV_FRM, CLM_ACTV_TO, CLM_ALLCTD_AMT,
                        CLM_PSEUDO_BNK_IND, CLM_ACCT_STTS, CLM_IBSL_CRDT_XTND, CLM_RSTRCT_LST_ID, CLM_ACCNT_CTGRY_ID,
                        CLM_CLNT_CTGRY_ID, CLM_CIF_NMBR, CLM_BLK_TRD_AMT, CLM_GRSS_EXP_LMT, CLM_B2K_CD, CLM_TDS_RT,
                        CLM_MF_ALLCTD_AMT, CLM_GRSS_LMT_UTLZD, CLM_WAP_REQ, CLM_INST_FLG, CLM_WAP_PRECISION, CLM_SLCTD_FLG,
                        CLM_CLNT_LVL, CLM_MF_MAX_OPT, CLM_MF_MAX_VAL, CLM_BTST_ALLWD_FLG, CLM_BP_ID, CLM_ALIAS_NAME,
                        CLM_TRD_FLG, CLM_PRM_BP_ID, CLM_LST_UPD_BY, CLM_LST_UPD_DT, CLM_CLNT_CD, CLM_PLG_ALLWD_FLG,
                        CLM_NCD_CLNT_LVL, CLM_BRKR_PLAN_CD, CLM_CP_CD, CLM_CDX_CLNT_LVL, CLM_PNNY_FLG, CLM_FNO_FEATURES,
                        CLM_BRKR_CMPT_FLG, CLM_OPT_SCHM_CD, CLM_SPAN_ALLWD, CLM_PREPAID_ALLWD, CLM_BSESPAN_ALLWD,
                        CLM_LPC_PRCNTG, CLM_PRPD_CUST_TYP, CLM_NCD_FLG, CLM_IGAIN_FP_FLG, CLM_IGAIN_FP_SCHM_CD,
                        CLM_IGAIN_OP_FLG, CLM_IGAIN_OP_SCHM_CD, CLM_PLG_LSTPRCS_TM, CLM_MF_TPA_ALLCTD_AMT,
                        CLM_BULLET_SCHM_FLG, CLM_BULLET_SCHM_TRIAL_FLG, CLM_ISEC_MRGN_AMT_NSE, CLM_ISEC_MRGN_AMT_BSE,
                        CLM_SQRFMD_STTS, CLM_SQRFMD_UPD_DT, CLM_ESOP_ALLWD, CLM_WALLET_AMT, CLM_IPO_ALLCTD_AMT,
                        CLM_EQ_BNK_ALLCTD_AMT, CLM_MF_BNK_ALLCTD_AMT, CLM_QRTLY_STLMNT_DT, CLM_OP20_FLG, CLM_OP20_SCHM_CD,
                        CLM_PLG_MODE, CLM_MF_MODE_DT, CLM_MF_DMAT_ACC, CLM_CDX_SPAN_ALLWD, CLM_ISEC_T5_AMT,
                        CLM_PREF_XCHNG_CD, CLM_EXCPTN_MTF_CLIENT_LVL_LMT, CLM_EXCPTN_MTF_CLNT_CHK, CLM_MF_ALLCTD_AMT_DEP,
                        CLM_RPTS_CNSNT_FLG, CLM_CNT_PENNY_ORDR_FLG, CLM_EXCPTN_CNT_IND, CLM_LOW_VOL_TRD_FLG, CLM_FLT_BRKG_FLG,
                        CLM_UPSTREAM_AMT, CLM_BRZE_FLG, CLM_CUST_LMT, CLM_FD_ALLCTD_AMT
                    ) FROM STDIN WITH CSV
                    """,
                    csv_file
                )
            self.postgres_connection.commit()
            insert_end_time = datetime.now()
            print("insert time ",insert_end_time - insert_start_time)  
            self.log_time_taken(insert_start_time, insert_end_time, "Inserting data into PostgreSQL using COPY")
            logger.info("Data inserted into PostgreSQL successfully.")

            # Clean up the temporary CSV file
            os.remove(csv_file_path)
        else:
            logger.info("No data to insert.")


    ########################################
    ## Closing All The Connection Oracle  ##
    ## Database And PostgresSql           ##
    ##                                    ##
    ##                                    ##
    ########################################
        

    def close_connections(self):
        if hasattr(self, 'oracle_cursor') and self.oracle_cursor:
            self.oracle_cursor.close()
        if hasattr(self, 'oracle_connection') and self.oracle_connection:
            self.oracle_connection.close()
        if hasattr(self, 'postgres_cursor') and self.postgres_cursor:
            self.postgres_cursor.close()
        if hasattr(self, 'postgres_connection') and self.postgres_connection:
            self.pg_pool.putconn(self.postgres_connection)

    def run(self):
        overall_start_time = datetime.now()

        self.connect_to_oracle()
        if not hasattr(self, 'oracle_cursor'):
            return

        self.fetch_data_from_oracle()

        self.connect_to_postgres()
        if not hasattr(self, 'postgres_cursor'):
            return

        self.insert_data_to_postgres()

        self.close_connections()

        overall_end_time = datetime.now()
        self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
        logger.info("Closed all database connections.")


if __name__ == "__main__":
    db_manager = DatabaseManager()
    db_manager.run()
