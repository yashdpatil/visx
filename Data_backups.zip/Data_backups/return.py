import configparser
import logging
from datetime import datetime
import csv
import psycopg2
from psycopg2 import pool

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManager:
    def __init__(self, config_file=r'D:\codings\Data_backups\config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        # Initialize PostgreSQL connection pool
        self.postgres_user = self.config['DatabaseConfig']['postgres_user']
        self.postgres_password = self.config['DatabaseConfig']['postgres_password']
        self.postgres_host = self.config['DatabaseConfig']['postgres_host']
        self.postgres_port = self.config['DatabaseConfig']['postgres_port']
        self.postgres_db = self.config['DatabaseConfig']['postgres_db']

        self.pg_pool = pool.SimpleConnectionPool(
            1, 20, user=self.postgres_user, password=self.postgres_password,
            host=self.postgres_host, port=self.postgres_port, database=self.postgres_db
        )

    def log_time_taken(self, start_time, end_time, task_description):
        time_taken = end_time - start_time
        logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")

    def connect_to_postgres(self):
        try:
            self.postgres_connection = self.pg_pool.getconn()
            logger.info("Connected to PostgreSQL Database.")
            self.postgres_cursor = self.postgres_connection.cursor()
        except psycopg2.DatabaseError as e:
            logger.error("PostgreSQL Database error occurred:")
            logger.error(f"Error message: {e}")

    def fetch_data_from_postgres(self):
        fetch_start_time = datetime.now()
        query = """
            SELECT fus_clm_mtch_accnt, fus_xchng_cd, fus_undrlyng, fus_indstk, fus_uibuy_qty, fus_uibuy_val,
                   fus_uisell_qty, fus_uisell_val, fus_uexbuy_qty, fus_uexbuy_val, fus_uexsell_qty, fus_uexsell_val,
                   fus_ubuy_exctd_qty, fus_usell_exctd_qty, fus_uopnpstn_flw, fus_uopnpstn_qty, fus_uopnpstn_val,
                   fus_umtm_opn_val, fus_initial_mrgn, fus_span_wemult_mrgn, fus_eba_expr_mrgn, fus_uspan_wenov_mrgn,
                   fus_multiplier, fus_uspan_nenov_mrgn, fus_net_optn_val, fus_mtm_flg, fus_trd_dt, fus_ntnl_pl,
                   fus_blckd_pl, fus_min_mrgn, fus_reqd_initial_mrgn, fus_ucc_cd
            FROM fus_fo_undrlyng_spn_pstn
        """
        self.postgres_cursor.execute(query)
        self.rows = self.postgres_cursor.fetchall()

        # Fetch column names
        self.columns = [desc[0] for desc in self.postgres_cursor.description]
        
        fetch_end_time = datetime.now()
        logger.info(f"Fetched {len(self.rows)} rows from PostgreSQL.")
        self.log_time_taken(fetch_start_time, fetch_end_time, "Fetching data from PostgreSQL")

    def save_data_to_csv(self):
        if self.rows:
            csv_file_path = 'rows.csv'
            save_start_time = datetime.now()
            with open(csv_file_path, mode='w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file)
                
                # Write column headers
                csv_writer.writerow(self.columns)
                
                # Write data rows
                csv_writer.writerows(self.rows)
                
            save_end_time = datetime.now()
            self.log_time_taken(save_start_time, save_end_time, "Saving data to CSV")
            logger.info("Data saved to CSV file successfully.")
        else:
            logger.info("No data to save.")

    def close_connections(self):
        if hasattr(self, 'postgres_cursor') and self.postgres_cursor:
            self.postgres_cursor.close()
        if hasattr(self, 'postgres_connection') and self.postgres_connection:
            self.pg_pool.putconn(self.postgres_connection)

    def run(self):
        overall_start_time = datetime.now()

        self.connect_to_postgres()
        if not hasattr(self, 'postgres_cursor'):
            return

        self.fetch_data_from_postgres()
        self.save_data_to_csv()
        self.close_connections()

        overall_end_time = datetime.now()
        self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
        logger.info("Closed all database connections.")


if __name__ == "__main__":
    db_manager = DatabaseManager()
    db_manager.run()
