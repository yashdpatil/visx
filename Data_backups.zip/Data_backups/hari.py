import configparser
import logging
from datetime import datetime
from sqlalchemy import create_engine, MetaData, Table
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, config_file=r'D:\codings\Data_backups\config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        # Initialize Oracle engine
        self.oracle_user = self.config['DatabaseConfig']['oracle_user']
        self.oracle_password = self.config['DatabaseConfig']['oracle_password']
        self.oracle_dsn = self.config['DatabaseConfig']['oracle_dsn']
        self.oracle_engine = create_engine(f'oracle+cx_oracle://{self.oracle_user}:{self.oracle_password}@{self.oracle_dsn}')

        # Initialize PostgreSQL engine
        self.postgres_user = self.config['DatabaseConfig']['postgres_user']
        self.postgres_password = self.config['DatabaseConfig']['postgres_password']
        self.postgres_host = self.config['DatabaseConfig']['postgres_host']
        self.postgres_port = self.config['DatabaseConfig']['postgres_port']
        self.postgres_db = self.config['DatabaseConfig']['postgres_db']
        self.postgres_engine = create_engine(f'postgresql://{self.postgres_user}:{self.postgres_password}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}')

    def log_time_taken(self, start_time, end_time, task_description):
        time_taken = end_time - start_time
        logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")

    def insert_data(self, target_session, source_schema, table, data):
        if data:
            target_session.execute("SET session_replication_role = replica;")
            target_session.execute(table.insert(), data)
            target_session.execute("SET session_replication_role = DEFAULT;")
            target_session.commit()

    def get_column_string(self, table):
        column_list = table.columns.keys()
        keywords = ['where', 'from', 'select', 'comment', 'order']
        column_list = ['"{}"'.format(x.upper()) if x.lower() in keywords else x for x in column_list] 
        column_str = ', '.join(column_list)
        return column_str

    def copy_data(self, source_engine, source_schema, target_engine, table_name, chunksize=10000, logged=True, trialrun=False):
        SourceSession = sessionmaker(bind=source_engine)
        source_session = SourceSession()
        TargetSession = sessionmaker(bind=target_engine)
        target_session = TargetSession()

        metadata = MetaData()
        table = Table(table_name, metadata, autoload_with=source_engine, schema=source_schema)

        msg = f'Began copy of {source_schema}.{table.name} at {datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}'
        logger.info(msg)

        target_session.execute(f"SET SEARCH_PATH TO {source_schema};")

        logswitch = False
        if not logged:
            try:
                target_session.execute(f'ALTER TABLE "{table.name}" SET UNLOGGED')
                logswitch = True
            except SQLAlchemyError:
                target_session.rollback()
                target_session.execute(f"SET SEARCH_PATH TO {source_schema};")
                msg = f"Unable to disable logging for {source_schema}.{table.name}"
                logger.info(msg)

        columns = self.get_column_string(table)

        offset = 0
        query = f"""SELECT {columns}
                    FROM {source_schema}.{table.name}
                    WHERE ROWNUM <= {chunksize}"""
        data = source_session.execute(query).fetchall()

        while data:
            self.insert_data(target_session, source_schema, table, data)

            msg = f'\tCopied rows {offset}-{offset + chunksize} of {source_schema}.{table.name} at {datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}'
            logger.info(msg)

            if trialrun and offset > 200:
                break

            offset += chunksize
            query = f"""SELECT {columns}
                        FROM (SELECT a.*, ROWNUM rnum
                              FROM (SELECT * FROM {source_schema}.{table.name}) a
                              WHERE ROWNUM <= {offset + chunksize})
                        WHERE rnum > {offset}"""
            
            try:
                data = source_session.execute(query).fetchall()
            except SQLAlchemyError:
                data = None
                break

        if logswitch:
            target_session.execute(f'ALTER TABLE "{table.name}" SET LOGGED')

        msg = f'Finished copy of {source_schema}.{table.name} at {datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")}'
        logger.info(msg)

        source_session.close()
        target_session.close()

    def run(self):
        overall_start_time = datetime.now()

        source_schema = "system"
        table_name = "CLM_CLNT_MSTR"

        self.copy_data(self.oracle_engine, source_schema, self.postgres_engine, table_name)

        overall_end_time = datetime.now()
        self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
        logger.info("Closed all database connections.")

if __name__ == "__main__":
    db_manager = DatabaseManager()
    db_manager.run()
