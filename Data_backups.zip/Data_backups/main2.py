# import configparser
# import logging
# from datetime import datetime
# import pandas as pd
# from sqlalchemy import create_engine
# import cx_Oracle

# # Setup logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# class DatabaseManager:
#     def __init__(self, config_file=r'D:\codings\Data_backups\config.ini'):
#         self.config = configparser.ConfigParser()
#         self.config.read(config_file)

#         # Initialize Oracle connection details
#         self.oracle_user = self.config['DatabaseConfig']['oracle_user']
#         self.oracle_password = self.config['DatabaseConfig']['oracle_password']
#         self.oracle_dsn = self.config['DatabaseConfig']['oracle_dsn']

#         # Initialize PostgreSQL connection details
#         self.postgres_user = self.config['DatabaseConfig']['postgres_user']
#         self.postgres_password = self.config['DatabaseConfig']['postgres_password']
#         self.postgres_host = self.config['DatabaseConfig']['postgres_host']
#         self.postgres_port = self.config['DatabaseConfig']['postgres_port']
#         self.postgres_db = self.config['DatabaseConfig']['postgres_db']

#         # Create SQLAlchemy engines for both databases
#         self.oracle_engine = create_engine(f'oracle+cx_oracle://{self.oracle_user}:{self.oracle_password}@{self.oracle_dsn}')
#         self.postgres_engine = create_engine(f'postgresql://{self.postgres_user}:{self.postgres_password}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}')

#     def log_time_taken(self, start_time, end_time, task_description):
#         time_taken = end_time - start_time
#         logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")

#     def fetch_data_from_oracle(self):
#         oracle_query = """
#             SELECT employee_id, first_name, last_name, department_id, salary
#             FROM Person
#         """
#         fetch_start_time = datetime.now()
#         df = pd.read_sql(oracle_query, self.oracle_engine)
#         fetch_end_time = datetime.now()
#         self.log_time_taken(fetch_start_time, fetch_end_time, "Fetching data from Oracle")
#         logger.info(f"Fetched {len(df)} rows from Oracle.")
#         return df

#     def insert_data_to_postgres(self, df):
#         if not df.empty:
#             insert_start_time = datetime.now()
#             df.to_sql('Person', self.postgres_engine, if_exists='append', index=False)
        
#             insert_end_time = datetime.now()
#             self.log_time_taken(insert_start_time, insert_end_time, "Inserting data into PostgreSQL")
#             logger.info("Data inserted into PostgreSQL successfully.")
#         else:
#             logger.info("No data to insert.")

#     def run(self):
#         overall_start_time = datetime.now()

#         df = self.fetch_data_from_oracle()
#         self.insert_data_to_postgres(df)

#         overall_end_time = datetime.now()
#         self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
#         logger.info("Process completed successfully.")

# if __name__ == "__main__":
#     db_manager = DatabaseManager()
#     db_manager.run()


import configparser
import logging
from datetime import datetime
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool
from concurrent.futures import ThreadPoolExecutor

class DatabaseManager:
    def __init__(self, config_file='config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        # Initialize Oracle connection details
        self.oracle_user = self.config['DatabaseConfig']['oracle_user']
        self.oracle_password = self.config['DatabaseConfig']['oracle_password']
        self.oracle_dsn = self.config['DatabaseConfig']['oracle_dsn']

        # Initialize PostgreSQL connection details
        self.postgres_user = self.config['DatabaseConfig']['postgres_user']
        self.postgres_password = self.config['DatabaseConfig']['postgres_password']
        self.postgres_host = self.config['DatabaseConfig']['postgres_host']
        self.postgres_port = self.config['DatabaseConfig']['postgres_port']
        self.postgres_db = self.config['DatabaseConfig']['postgres_db']

        # Create SQLAlchemy engines for both databases with connection pooling
        self.oracle_engine = create_engine(
            f'oracle+cx_oracle://{self.oracle_user}:{self.oracle_password}@{self.oracle_dsn}',
            poolclass=QueuePool,
            pool_size=10,
            max_overflow=20
        )
        self.postgres_engine = create_engine(
            f'postgresql://{self.postgres_user}:{self.postgres_password}@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}',
            poolclass=QueuePool,
            pool_size=10,
            max_overflow=20
        )

        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)

    def log_time_taken(self, start_time, end_time, task_description):
        time_taken = end_time - start_time
        self.logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")

    def fetch_and_insert_data(self):
        oracle_query = """
            SELECT employee_id, first_name, last_name, department_id, salary
            FROM Person
        """
        fetch_start_time = datetime.now()
        chunk_count = 0

        with ThreadPoolExecutor(max_workers=8) as executor:
            futures = []

            for chunk in pd.read_sql_query(oracle_query, self.oracle_engine, chunksize=10000):
                chunk_count += 1
                self.logger.info(f"Processing chunk {chunk_count} with {len(chunk)} rows.")
                futures.append(executor.submit(self.insert_data_to_postgres, chunk))

            for future in futures:
                future.result()  # Ensure all tasks are completed

        fetch_end_time = datetime.now()
        self.log_time_taken(fetch_start_time, fetch_end_time, "Fetching and inserting data")

    def insert_data_to_postgres(self, df):
        if not df.empty:
            insert_start_time = datetime.now()
            # Write the DataFrame to a CSV file
            csv_file = 'temp_data.csv'
            df.to_csv(csv_file, index=False, header=False)

            # Use the COPY command to load data from the CSV file
            with self.postgres_engine.raw_connection() as conn:
                cursor = conn.cursor()
                with open(csv_file, 'r') as f:
                    cursor.copy_expert("COPY Person FROM STDIN WITH CSV", f)
                conn.commit()

            insert_end_time = datetime.now()
            self.log_time_taken(insert_start_time, insert_end_time, "Inserting chunk into PostgreSQL")
            self.logger.info(f"Chunk with {len(df)} rows inserted into PostgreSQL successfully.")
        else:
            self.logger.info("No data to insert.")

    def run(self):
        overall_start_time = datetime.now()

        self.fetch_and_insert_data()

        overall_end_time = datetime.now()
        self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
        self.logger.info("Process completed successfully.")

if __name__ == "__main__":
    db_manager = DatabaseManager()
    db_manager.run()
