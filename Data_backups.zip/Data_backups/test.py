# from sqlalchemy import MetaData, Table, create_engine
# import cx_Oracle

# source_engine = create_engine('system/root@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=192.168.56.1)(Port=1521))(CONNECT_DATA=(SID=xe)))')
# conn = source_engine.connect()

# metadata = MetaData()
# table = Table("CLM_CLNT_MSTR", metadata, autoload_with=source_engine, schema="demo")

# print(table)


from sqlalchemy import create_engine
import pandas as pd
import time

# Timing the execution

# Define source and destination connection strings
source_engine = create_engine('oracle+cx_oracle://system:root@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=localhost)(Port=1521))(CONNECT_DATA=(SID=xe)))')
dest_engine = create_engine('postgresql://postgres:root@localhost:5432/demo1')

# Connect to the source database
with source_engine.connect() as conn:
    print("Connected to Oracle database.")

    start_time = time.time()
    # Read table data using SQL query
    sql_df = pd.read_sql('''SELECT CLM_MTCH_ACCNT, CLM_ORG_IND, CLM_CLNT_TTL, CLM_CLNT_NM, CLM_ACTV_FRM, CLM_ACTV_TO, CLM_ALLCTD_AMT,
                   CLM_PSEUDO_BNK_IND, CLM_ACCT_STTS, CLM_IBSL_CRDT_XTND, CLM_RSTRCT_LST_ID, CLM_ACCNT_CTGRY_ID,
                   CLM_CLNT_CTGRY_ID, CLM_CIF_NMBR, CLM_BLK_TRD_AMT, CLM_GRSS_EXP_LMT, CLM_B2K_CD, CLM_TDS_RT,
                   CLM_MF_ALLCTD_AMT, CLM_GRSS_LMT_UTLZD, CLM_WAP_REQ, CLM_INST_FLG, CLM_WAP_PRECISION, CLM_SLCTD_FLG,
                   CLM_CLNT_LVL, CLM_MF_MAX_OPT, CLM_MF_MAX_VAL, CLM_BTST_ALLWD_FLG, CLM_BP_ID, CLM_ALIAS_NAME,
                   CLM_TRD_FLG, CLM_PRM_BP_ID, CLM_LST_UPD_BY, CLM_LST_UPD_DT, CLM_CLNT_CD, CLM_PLG_ALLWD_FLG,
                   CLM_NCD_CLNT_LVL, CLM_BRKR_PLAN_CD, CLM_CP_CD, CLM_CDX_CLNT_LVL, CLM_PNNY_FLG, CLM_FNO_FEATURES,
                   CLM_BRKR_CMPT_FLG, CLM_OPT_SCHM_CD, CLM_SPAN_ALLWD, CLM_PREPAID_ALLWD, CLM_BSESPAN_ALLWD,
                   CLM_LPC_PRCNTG, CLM_PRPD_CUST_TYP, CLM_NCD_FLG, CLM_IGAIN_FP_FLG, CLM_IGAIN_FP_SCHM_CD,
                   CLM_IGAIN_OP_FLG, CLM_IGAIN_OP_SCHM_CD, CLM_PLG_LSTPRCS_TM, CLM_MF_TPA_ALLCTD_AMT,
                   CLM_BULLET_SCHM_FLG, CLM_BULLET_SCHM_TRIAL_FLG, CLM_ISEC_MRGN_AMT_NSE, CLM_ISEC_MRGN_AMT_BSE,
                   CLM_SQRFMD_STTS, CLM_SQRFMD_UPD_DT, CLM_ESOP_ALLWD, CLM_WALLET_AMT, CLM_IPO_ALLCTD_AMT,
                   CLM_EQ_BNK_ALLCTD_AMT, CLM_MF_BNK_ALLCTD_AMT, CLM_QRTLY_STLMNT_DT, CLM_OP20_FLG, CLM_OP20_SCHM_CD,
                   CLM_PLG_MODE, CLM_MF_MODE_DT, CLM_MF_DMAT_ACC, CLM_CDX_SPAN_ALLWD, CLM_ISEC_T5_AMT,
                   CLM_PREF_XCHNG_CD, CLM_EXCPTN_MTF_CLIENT_LVL_LMT, CLM_EXCPTN_MTF_CLNT_CHK, CLM_MF_ALLCTD_AMT_DEP,
                   CLM_RPTS_CNSNT_FLG, CLM_CNT_PENNY_ORDR_FLG, CLM_EXCPTN_CNT_IND, CLM_LOW_VOL_TRD_FLG, CLM_FLT_BRKG_FLG,
                   CLM_UPSTREAM_AMT, CLM_BRZE_FLG, CLM_CUST_LMT, CLM_FD_ALLCTD_AMT
            FROM CLM_CLNT_MSTR  where rownum < 200000''', con=conn)
    
    # Optionally, write the data to the destination PostgreSQL database
    # sql_df.to_sql('clm_clnt_mstr', con=dest_engine, if_exists='replace', index=False)

    end_time = time.time()

    # print(sql_df)
    print("Time taken: ", end_time - start_time)
# print(sql_df)

with dest_engine.connect() as conn:
    start_time = time.time()
    sql_df.to_sql('clm_clnt_mstr', con=conn, if_exists='replace', index=False,chunksize=100)
    conn.commit()
    end_time = time.time()
    print("Time taken to insert data: ", end_time - start_time)

print(sql_df.head())