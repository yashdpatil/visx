import configparser
import logging
from datetime import datetime
import csv
import os
import cx_Oracle
import psycopg2
from psycopg2 import pool
import time

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseManager:
    def __init__(self, config_file=r'D:\codings\Data_backups\config.ini'):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        # Initialize Oracle connection
        self.oracle_user = self.config['DatabaseConfig']['oracle_user']
        self.oracle_password = self.config['DatabaseConfig']['oracle_password']
        self.oracle_dsn = self.config['DatabaseConfig']['oracle_dsn']

        # Initialize PostgreSQL connection pool
        self.postgres_user = self.config['DatabaseConfig']['postgres_user']
        self.postgres_password = self.config['DatabaseConfig']['postgres_password']
        self.postgres_host = self.config['DatabaseConfig']['postgres_host']
        self.postgres_port = self.config['DatabaseConfig']['postgres_port']
        self.postgres_db = self.config['DatabaseConfig']['postgres_db']

        self.pg_pool = pool.SimpleConnectionPool(
            1, 20, user=self.postgres_user, password=self.postgres_password,
            host=self.postgres_host, port=self.postgres_port, database=self.postgres_db
        )

    def log_time_taken(self, start_time, end_time, task_description):
        time_taken = end_time - start_time
        logger.info(f"{task_description} took {time_taken.total_seconds():.2f} seconds.")

    def connect_to_oracle(self):
        try:
            self.oracle_connection = cx_Oracle.connect(
                user=self.oracle_user, password=self.oracle_password, dsn=self.oracle_dsn
            )
            logger.info("Connected to Oracle Database.")
            self.oracle_cursor = self.oracle_connection.cursor()
        except cx_Oracle.DatabaseError as e:
            error, = e.args
            logger.error("Oracle Database error occurred:")
            logger.error(f"Error code: {error.code}")
            logger.error(f"Error message: {error.message}")

    def fetch_data_from_oracle(self):
        curr  = time.time()
        oracle_query = """
            SELECT fus_clm_mtch_accnt, fus_xchng_cd, fus_undrlyng, fus_indstk, fus_uibuy_qty, fus_uibuy_val,
                   fus_uisell_qty, fus_uisell_val, fus_uexbuy_qty, fus_uexbuy_val, fus_uexsell_qty, fus_uexsell_val,
                   fus_ubuy_exctd_qty, fus_usell_exctd_qty, fus_uopnpstn_flw, fus_uopnpstn_qty, fus_uopnpstn_val,
                   fus_umtm_opn_val, fus_initial_mrgn, fus_span_wemult_mrgn, fus_eba_expr_mrgn, fus_uspan_wenov_mrgn,
                   fus_multiplier, fus_uspan_nenov_mrgn, fus_net_optn_val, fus_mtm_flg, fus_trd_dt, fus_ntnl_pl,
                   fus_blckd_pl, fus_min_mrgn, fus_reqd_initial_mrgn, fus_ucc_cd
            FROM FUS_FO_UNDRLYNG_SPN_PSTN
        """
        self.oracle_cursor.execute(oracle_query)
        self.rows = self.oracle_cursor.fetchall()
        end = time.time()
        logger.info(f"Fetched {len(self.rows)} rows from Oracle.")
    
    def clean_data(self, data):
        # Clean invalid UTF-8 characters
        return [(item.replace('\x00', '') if isinstance(item, str) else item) for item in data]


    def connect_to_postgres(self):
        try:
            self.postgres_connection = self.pg_pool.getconn()
            logger.info("Connected to PostgreSQL Database.")
            self.postgres_cursor = self.postgres_connection.cursor()
        except psycopg2.DatabaseError as e:
            logger.error("PostgreSQL Database error occurred:")
            logger.error(f"Error message: {e}")

    def insert_data_to_postgres(self):
        if self.rows:
            insert_start_time = datetime.now()
            csv_file_path = 'rows.csv'
            with open(csv_file_path, mode='w', newline='') as csv_file:
                csv_writer = csv.writer(csv_file)
                for row in self.rows:
                    csv_writer.writerow(self.clean_data(row))

            # Use COPY command to bulk insert data
            with open(csv_file_path, mode='r') as csv_file:
                self.postgres_cursor.copy_expert(
                    """
                    COPY fus_fo_undrlyng_spn_pstn (
                        fus_clm_mtch_accnt, fus_xchng_cd, fus_undrlyng, fus_indstk, fus_uibuy_qty, fus_uibuy_val,
                        fus_uisell_qty, fus_uisell_val, fus_uexbuy_qty, fus_uexbuy_val, fus_uexsell_qty, fus_uexsell_val,
                        fus_ubuy_exctd_qty, fus_usell_exctd_qty, fus_uopnpstn_flw, fus_uopnpstn_qty, fus_uopnpstn_val,
                        fus_umtm_opn_val, fus_initial_mrgn, fus_span_wemult_mrgn, fus_eba_expr_mrgn, fus_uspan_wenov_mrgn,
                        fus_multiplier, fus_uspan_nenov_mrgn, fus_net_optn_val, fus_mtm_flg, fus_trd_dt, fus_ntnl_pl,
                        fus_blckd_pl, fus_min_mrgn, fus_reqd_initial_mrgn, fus_ucc_cd
                    ) FROM STDIN WITH CSV
                    """,
                    csv_file
                )
            self.postgres_connection.commit()
            insert_end_time = datetime.now()
            self.log_time_taken(insert_start_time, insert_end_time, "Inserting data into PostgreSQL using COPY")
            logger.info("Data inserted into PostgreSQL successfully.")

            # Clean up the temporary CSV file
            # os.remove(csv_file_path)
        else:
            logger.info("No data to insert.")

    def close_connections(self):
        if hasattr(self, 'oracle_cursor') and self.oracle_cursor:
            self.oracle_cursor.close()
        if hasattr(self, 'oracle_connection') and self.oracle_connection:
            self.oracle_connection.close()
        if hasattr(self, 'postgres_cursor') and self.postgres_cursor:
            self.postgres_cursor.close()
        if hasattr(self, 'postgres_connection') and self.postgres_connection:
            self.pg_pool.putconn(self.postgres_connection)

    def run(self):
        overall_start_time = datetime.now()

        self.connect_to_oracle()
        if not hasattr(self, 'oracle_cursor'):
            return

        self.fetch_data_from_oracle()

        self.connect_to_postgres()
        if not hasattr(self, 'postgres_cursor'):
            return

        self.insert_data_to_postgres()

        self.close_connections()

        overall_end_time = datetime.now()
        self.log_time_taken(overall_start_time, overall_end_time, "Overall process")
        logger.info("Closed all database connections.")


if __name__ == "__main__":
    db_manager = DatabaseManager()
    db_manager.run()
